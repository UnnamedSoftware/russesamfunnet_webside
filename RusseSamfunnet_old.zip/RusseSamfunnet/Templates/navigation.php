<<<<<<< HEAD
<a href="feed.php">Feed</a>
<a href="knots.php">Knuter</a>
<a href="scoreboard.php">Scoreboard</a>
<a href="community.php">Samfunn</a>
<a href="userprofile.php">Brukerprofil</a>
<a href="#" onclick="logout()">Log ut</a>
=======
<link rel="stylesheet" type="text/css" href="CSS/menu.css">
<nav role="navigation">
  <div id="menuToggle">
    <!--click reciever for hamburger-->
    <input type="checkbox" />
    
    <!-- The hamburger -->
    <span></span>
    <span></span>
    <span></span>
    <ul id="menu">
      <a href="feed.php"><li>Feed</li></a>
      <a href="knots.php"><li>Knuter</li></a>
      <a href="scoreboard.php"><li>Scoreboard</li></a>
      <a href="community.php"><li>Mitt samfunn</li></a>
      <a href="userprofile.php"><li>Min profil</li></a>
    </ul>
  </div>
</nav>
>>>>>>> f4a9f859002d83ad318b5518f9a4578be385ef8d
