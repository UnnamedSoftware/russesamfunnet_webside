<?php
echo "<p>Copyright &copy; 2018 - " . date("Y") . " Unnamed softwares</p>";
?>