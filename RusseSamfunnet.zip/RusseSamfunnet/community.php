<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Standard Template</title>
        <link rel="stylesheet" type="text/css" href="CSS/normalize.css">
        <link rel="stylesheet" type="text/css" href="CSS/main.css">
    </head>
    <body>
        <nav>
            <?php include 'Templates/navigation.php';?>
        </nav>
        <div id="main">
        <p>test</p>
        
        </div>
        <footer>
            <?php include 'Templates/footer.php';?>
        </footer>
    </body>
</html>
